<!-- PHP INCLUDES -->
<?php
 session_start();
    //Set page title
    $pageTitle = 'Order Food';

    include "connect.php";
    include 'Includes/functions/functions.php';
    include "Includes/templates/header.php";
    include "Includes/templates/navbar.php";
?>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- ORDER FOOD PAGE STYLE -->
	<style type="text/css">
        body
        {
            background: #f7f7f7;
        }

		.text_header
		{
			margin-bottom: 5px;
    		font-size: 18px;
    		font-weight: bold;
    		line-height: 1.5;
    		margin-top: 22px;
    		text-transform: capitalize;
		}

        .items_tab
        {
            border-radius: 4px;
            background-color: white;
            overflow: hidden;
            box-shadow: 0 0 5px 0 rgba(60, 66, 87, 0.04), 0 0 10px 0 rgba(0, 0, 0, 0.04);
        }

        .itemListElement
        {
            font-size: 14px;
            line-height: 1.29;
            border-bottom: solid 1px #e5e5e5;
            cursor: pointer;
            padding: 16px 12px 18px 12px;
        }

        .item_details
        {
            width: auto;
            display: -webkit-box;
            display: -moz-box;
            display: -ms-flexbox;
            display: -webkit-flex;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -webkit-flex-direction: row;
            -webkit-box-pack: justify;
            -webkit-justify-content: space-between;
            -webkit-box-align: center;
            -webkit-align-items: center;
        }

        .item_label
        {
        	color: #9e8a78;
            border-color: #9e8a78;
            background: white;
            font-size: 12px;
            font-weight: 700;
        }

        .btn-secondary:not(:disabled):not(.disabled).active, .btn-secondary:not(:disabled):not(.disabled):active 
        {
            color: #fff;
            background-color: #9e8a78;
            border-color: #9e8a78;
        }

        .item_select_part
        {
            display: flex;
            -webkit-box-pack: justify;
            justify-content: space-between;
            -webkit-box-align: center;
            align-items: center;
            flex-shrink: 0;
        }

        .select_item_bttn
        {
            width: 55px;
            display: flex;
            margin-left: 30px;
            -webkit-box-pack: end;
            justify-content: flex-end;
        }

        .menu_price_field
        {
        	width: auto;
            display: flex;
            margin-left: 30px;
            -webkit-box-align: baseline;
            align-items: baseline;
        }

        .order_food_section
        {
            max-width: 720px;
            margin: 50px auto;
            padding: 0px 15px;
        }

        .item_label.focus,
        .item_label:focus
        {
            outline: none;
            background:initial;
            box-shadow: none;
            color: #9e8a78;
            border-color: #9e8a78;
        }

        .item_label:hover
        {
            color: #fff;
            background-color: #9e8a78;
            border-color: #9e8a78;
        }

        /* Make circles that indicate the steps of the form: */
        .step 
        {
            height: 15px;
            width: 15px;
            margin: 0 2px;
            background-color: #bbbbbb;
            border: none;  
            border-radius: 50%;
            display: inline-block;
            opacity: 0.5;
        }

        .step.active 
        {
            opacity: 1;
        }

        /* Mark the steps that are finished and valid: */
        .step.finish 
        {
            background-color: #4CAF50;
        }


        .order_food_tab
        {
            display: none;
        }

        .next_prev_buttons
        {
            background-color: #4CAF50;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 17px;
            cursor: pointer;
        }

        .client_details_tab  .form-control
        {
            background-color: #fff;
            border-radius: 0;
            padding: 25px 10px;
            box-shadow: none;
            border: 2px solid #eee;
        }

        .client_details_tab  .form-control:focus 
        {
            border-color: #ffc851;
            box-shadow: none;
            outline: none;
        }

	</style>

<section class="order_food_section">
    <div class="text_header">
        <span>
            Cart
        </span>
    </div>
    <form method="POST" action="complete.php">
        <div class="items_tab">

    
        <?php
        if(isset($_POST['submit_order_food_form']) && $_SERVER['REQUEST_METHOD'] === 'POST')
        {


         
    $selected_menus = $_POST['selected_menus'];

    //Client Details

    $client_full_name = test_input($_POST['client_full_name']);
    $delivery_address = test_input($_POST['client_delivery_address']);
    $client_phone_number = test_input($_POST['client_phone_number']);
    $client_email = test_input($_POST['client_email']);
    $special = test_input($_POST['client_special']);

    

   
  
    $con->beginTransaction();
    try
    {
       // Insert the client details into the database
        $stmtClient = $con->prepare("insert into clients(client_name, client_phone, client_email) values (?, ?, ?)");
        $stmtClient->execute(array($client_full_name, $client_phone_number, $client_email));
        $client_id = $con->lastInsertId();

        $stmt_special = $con->prepare('INSERT INTO specials (client_id, specials) VALUES (?, ?)');
        $stmt_special->execute([$client_id, $special]);



        $stmt_order = $con->prepare("insert into placed_orders(order_time, client_id, delivery_address) values (?, ?, ?)");
        $stmt_order->execute(array(Date("Y-m-d H:i"), $client_id, $delivery_address));
        
        $order_id = $con->lastInsertId();
        
        foreach ($selected_menus as $menu) {
            $stmt = $con->prepare("insert into in_order(order_id, menu_id) values (?, ?)");
            $stmt->execute(array($order_id, $menu));
        }


        $con->commit();
        
    }
    catch(Exception $e)
    {
        $con->rollBack();
        echo "<div class = 'alert alert-danger'>"; 
            echo $e->getMessage();
        echo "</div>";
    }

        $client_full_name = test_input($_POST['client_full_name']);
        $delivery_address = test_input($_POST['client_delivery_address']);
        $client_phone_number = test_input($_POST['client_phone_number']);
        $client_email = test_input($_POST['client_email']); ?>
        <input type="hidden" name="client_full_name" value="<?php echo $client_full_name; ?>">
        <input type="hidden" name="delivery_address" value="<?php echo $delivery_address; ?>">
        <input type="hidden" name="client_phone_number" value="<?php echo $client_phone_number; ?>">
        <input type="hidden" name="client_email" value="<?php echo $client_email; ?>">
        <?php
            // Selected Menus
            $selected_menus = $_POST['selected_menus'];

            $stmt = $con->prepare("SELECT menu_id, menu_name, menu_price FROM menus WHERE menu_id = ?");
            $total_price = 0;
            $selected_items = array();
            foreach($selected_menus as $menu_id) {
                if(strpos($menu_id, "cancel") !== false) {
                    // Menu item has been canceled
                    $menu_id = str_replace("cancel", "", $menu_id);
                    // Remove the canceled item from the list of selected menus
                    $key = array_search($menu_id, $selected_menus);
                    if ($key !== false) {
                        unset($selected_menus[$key]);
                    }
                } else {
                    // Menu item is selected
                    $stmt->bindParam(1, $menu_id, PDO::PARAM_INT);
                    $stmt->execute();
                    $menu_details = $stmt->fetch(PDO::FETCH_ASSOC);
                    $total_price += $menu_details['menu_price'];
                    $selected_items[] = $menu_details;
                }
            }
            // Display the remaining selected menu items
            foreach($selected_items as $menu_details) {
            ?>
                <div class='itemListElement'>
                    <div class='item_details' style="background-color:white;">
                        <div>
                            <?php echo $menu_details['menu_name']; ?>
                        </div>
                        <div class='item_select_part' style="background-color:white;">
                            <div class='menu_price_field' style="background-color:white;">
                                <span style='font-weight: bold;'><?php echo $menu_details['menu_price'] . " $"; ?></span>
                            </div>
                        </div>
                        <div class="select_item_bttn">
                            <div class="btn-group-toggle" data-toggle="buttons">
                                <label class="menu_label item_label btn btn-secondary">
                                <input type="checkbox" name="selected_menus[]" value="<?php echo $menu_details['menu_id']?>" autocomplete="off">Available
                              </label>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            }
            // Display the total price of selected menus
            if(count($selected_items) > 0) {

                
                 $final_price = 1.04 * $total_price;
                 $tax = 0.04 * $total_price;
                 $f_p = number_format($final_price, 2);
                 $t = number_format($tax, 2);
                
                 $_SESSION['f_p'] = $f_p;

                echo "<br> <p class='h5 text-left text-success ml-3'> Total price: " . $total_price . "$ </p> ";
                echo "<br> <p class='h5 text-left text-success ml-3'> Tax : " . $t . "$ </p> ";
                echo "<br> <p class='h5 text-left text-success ml-3'> Final Price  : " . $f_p. "$ </p> <br> <br>";
            }
            // Display submit button
            echo "<div class='text-center mb-2' style='margin-top:-50px;'> ";
            echo '<a href="complete.php"><input type="submit" style="width:200px;" name="submit_non_canceled_menus"  class="btn btn-primary text-center" value="On store pick up"></a><br> <br>';
            echo '<a target="_blank" href="https://www.doordash.com/restaurants-near-me/"><input type="button" name="submit_non_canceled_menus" class="btn btn-success" value="Deliver using Doordash"></a>';
            echo "</div>";
        }
        ?>
        </div>
    </form>


<script type="text/javascript">
    // Get all cancel buttons
    var cancelButtons = document.querySelectorAll('.itemListElement input[type="checkbox"]');
    
    // Add event listener to each cancel button
    cancelButtons.forEach(function(cancelButton) {
        cancelButton.addEventListener('change', function() {
            var selectedMenus = document.querySelectorAll('.itemListElement input[type="checkbox"]:checked');
            var canceledMenuId = this.value.replace('cancel', '');
            var canceledMenuElement = document.querySelector('.itemListElement input[value="' + canceledMenuId + '"]').parentNode.parentNode.parentNode;
            // Remove the canceled menu from the list of selected menus
            if (selectedMenus.length > 0) {
                // Recalculate the total price
                var totalPrice = 0;
                selectedMenus.forEach(function(selectedMenu) {
                    var selectedMenuElement = selectedMenu.parentNode.parentNode.parentNode;
                    var priceElement = selectedMenuElement.querySelector('.menu_price_field span');
                    totalPrice += parseFloat(priceElement.textContent);
                });
                // Display the new total price
                var totalPriceElement = document.querySelector('.items_tab .total_price');
                if (!totalPriceElement) {
                    totalPriceElement = document.createElement('div');
                    totalPriceElement.classList.add('total_price');
                    document.querySelector('.items_tab').appendChild(totalPriceElement);
                }
                totalPriceElement.textContent = 'Total price: ' + totalPrice + '$';
            } else {
                // Hide the total price
                var totalPriceElement = document.querySelector('.items_tab .total_price');
                if (totalPriceElement) {
                    totalPriceElement.parentNode.removeChild(totalPriceElement);
                }
            }
            // Remove the canceled menu from the list
            canceledMenuElement.parentNode.removeChild(canceledMenuElement);
        });
    });
</script>


<!-- -------------------------------------------------------------------------------------------------------------------------- -->
  
