<!-- PHP INCLUDES -->

<?php
    //Set page title
    $pageTitle = 'Table Reservation';

    include "connect.php";
    include 'Includes/functions/functions.php';
    include "Includes/templates/header.php";
    include "Includes/templates/navbar.php";


?>
    <style type="text/css">
        .table_reservation_section
        {
            max-width: 850px;
            margin: 50px auto;
            min-height: 500px;
        }

        .check_availability_submit
        {
            background: #ffc851;
            color: white;
            border-color: #ffc851;
            font-family: work sans,sans-serif;
        }
        .client_details_tab  .form-control
        {
            background-color: #fff;
            border-radius: 0;
            padding: 25px 10px;
            box-shadow: none;
            border: 2px solid #eee;
        }

        .client_details_tab  .form-control:focus 
        {
            border-color: #ffc851;
            box-shadow: none;
            outline: none;
        }
        .text_header
        {
            margin-bottom: 5px;
            font-size: 18px;
            font-weight: bold;
            line-height: 1.5;
            margin-top: 22px;
            text-transform: capitalize;
        }
        .layer
        {
            height: 100%;
        background: -moz-linear-gradient(top, rgba(45,45,45,0.4) 0%, rgba(45,45,45,0.9) 100%);
    background: -webkit-linear-gradient(top, rgba(45,45,45,0.4) 0%, rgba(45,45,45,0.9) 100%);
    background: linear-gradient(to bottom, rgba(45,45,45,0.4) 0%, rgba(45,45,45,0.9) 100%);
        }

    </style>

    <!-- START ORDER FOOD SECTION -->

    <section style="
    background: url(Design/images/food_pic.jpg);
    background-position: center bottom;
    background-repeat: no-repeat;
    background-size: cover;">
        <div class="layer">
            <div style="text-align: center;padding: 15px;">
                <h1 style="font-size: 120px; color: white;font-family: 'Kristi', cursive;
">Book a Table</h1>
            </div>
        </div>
        
    </section>

	<section class="table_reservation_section">

        <div class="container">
        <?php

if(isset($_POST['submit_table_reservation_form']) && $_SERVER['REQUEST_METHOD'] === 'POST')
{
    // Selected Date and Time
    $selected_date = $_POST['selected_date'];
    $selected_time = $_POST['selected_time'];
    $desired_date = $selected_date." ".$selected_time;

    // Number of Guests
    $number_of_guests = $_POST['number_of_guests'];

    // Client Details
    $client_full_name = test_input($_POST['client_full_name']);
    $client_phone_number = test_input($_POST['client_phone_number']);
    $client_email = test_input($_POST['client_email']);

    // Start transaction
    $con->beginTransaction();
    try
    {
        // Insert client details
        $stmtClient = $con->prepare("INSERT INTO table_reservation (date, time, num_people, client_name, email, phone_number) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtClient->execute(array($selected_date, $selected_time, $number_of_guests, $client_full_name, $client_email, $client_phone_number));
        $reservation_id = $con->lastInsertId();

        echo "<div class='alert alert-success'>Great! Your reservation has been created successfully.</div>";

        // Commit transaction
        $con->commit();
    }
    catch(Exception $e)
    {
        // Rollback transaction
        $con->rollBack();
        echo "<div class='alert alert-danger'>" . $e->getMessage() . "</div>";
    }

    // Close the database connection
    $con = null;
}

?>



            <div class="text_header">
                <span>
                    1. Select Date & Time
                </span>
            </div>
            <form method="POST" action="table-reservation.php">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <label for="selected_date">Date</label>
                            <!-- please add validation so that the date is not less than today -->
                            

                            <input type="date" value="<?php echo (isset($_POST['selected_date']))?$_POST['selected_date']:date('Y-m-d',strtotime("+1day")); ?>" class="form-control" name="selected_date" onchange="validateDate(this)" data-dirty="false">


                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <label for="selected_time">Time</label>
                            <input type="time" value="<?php echo (isset($_POST['selected_time']))?$_POST['selected_time']:date('H:i');  ?>" class="form-control" name="selected_time">
                        </div>
                    </div> 
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <label for="number_of_guests">How many people?</label>
                            <select class="form-control" name="number_of_guests">
                                <option value="1" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>
                                    One person
                                </option>
                                <option value="2" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Two people</option>
                                <option value="3" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Three people</option>
                                <option value="4" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Four people</option>
                                <option value="5" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Five people</option>
                                <option value="6" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Six people</option>
                                <option value="7" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Seven people</option>
                                <option value="8" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Eight people</option>
                                <option value="9" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Nine people</option>
                                <option value="10" <?php echo (isset($_POST['number_of_guests']))?"selected":"";  ?>>Ten people</option>

                            </select>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <div class="form-group">
                            <label for="check_availability" style="visibility: hidden;">Check Availability</label>
                            <input type="submit" class="form-control check_availability_submit" name="check_availability_submit">
                        </div>
                    </div>
                </div>
            </form>

            <!-- CHECKING AVAILABILITY OF TABLES -->

            <?php

                if(isset($_POST['check_availability_submit']))
                {
                    $selected_date = $_POST['selected_date'];
                    $selected_time = $_POST['selected_time'];
                    $number_of_guests = $_POST['number_of_guests'];

                    $stmt = $con->prepare("SELECT COUNT(*) FROM table_reservation WHERE date = ? AND time = ?");
                    $stmt->execute([$selected_date, $selected_time]);
                    $count = $stmt->fetchColumn();
                    if($count > 0)
                    {
                        ?>
                            <div class="error_div">
                                <span class="error_message" style="font-size: 16px; text-color:red;">Reservation exists please try again! </span>
                            </div>
                        <?php
                    }
                    else
                    {
                        ?>
                            <div class="text_header">
                                <span>
                                    2. Client details
                                </span>
                            </div>
                            <form method="POST" action="table-reservation.php">
                                <input type="hidden" name="selected_date" value="<?php echo $selected_date ?>">
                                <input type="hidden" name="selected_time" value="<?php echo $selected_time ?>">
                                <input type="hidden" name="number_of_guests" value="<?php echo $number_of_guests ?>">
                                <input type="hidden" name="table_id" value="<?php echo $table_id ?>">
                                <div class="client_details_tab">
                                    <div class="form-group colum-row row">
                                        <div class="col-sm-12">
                                            <input type="text" name="client_full_name" id="client_full_name" oninput="document.getElementById('required_fname').style.display = 'none'" onkeyup="this.value=this.value.replace(/[^\sa-zA-Z]/g,'');" class="form-control" placeholder="Full name">
                                            <div class="invalid-feedback" id="required_fname">
                                                Invalid Name!
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <input type="email" name="client_email" id="client_email" oninput="document.getElementById('required_email').style.display = 'none'" class="form-control" placeholder="E-mail">
                                            <div class="invalid-feedback" id="required_email">
                                                Invalid E-mail!
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="text"  name="client_phone_number" id="client_phone_number" oninput="document.getElementById('required_phone').style.display = 'none'" class="form-control" onkeyup="this.value=this.value.replace(/[^0-9]/g,'');" placeholder="Phone number">
                                            <div class="invalid-feedback" id="required_phone">
                                                Invalid Phone number!
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit_table_reservation_form" class="btn btn-info" value="Make a Reservation">
                                </div>
                            </form>
                        <?php
                    }

                }

            ?>
        </div>
    </section>

    <style type="text/css">
        .details_card
        {
            display: flex;
            align-items: center;
            margin: 150px 0px;
        }
        .details_card>span
        {
            float: left;
            font-size: 60px;
        }
        
        .details_card>div
        {
            float: left;
            font-size: 20px;
            margin-left: 20px;
            letter-spacing: 2px
        }
    </style>

    <section class="restaurant_details" style="background: url(Design/images/food_pic_2.jpg);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: 50% 0%;
    background-size: cover;
    color:white !important;
    min-height: 300px;">
        <div class="layer">
            <div class="container">
            <div class="row">
            <div class="col-md-3 details_card">
                <span>6</span>
                <div>
                    Total 
                    <br>
                    Reservations
                </div>
            </div>
            <div class="col-md-3 details_card">
                <span>6</span>
                <div>
                    Total 
                    <br>
                    Menus
                </div>
            </div>
            <div class="col-md-3 details_card">
                <span>6</span>
                <div>
                    Years of 
                    <br>
                    Experience
                </div>
            </div>
            <div class="col-md-3 details_card">
                <span>6</span>
                <div>
                    Profesionnal 
                    <br>
                    Cook
                </div>
            </div>
        </div>
        </div>
         </div>
    </section>

    <!-- FOOTER BOTTOM  -->

    <?php include "Includes/templates/footer.php"; ?>
    <script>
function validateDate(input) {
  var dateInput = input.value;
  var today = new Date().toISOString().slice(0,10);

  if (dateInput < today) {
    alert("Reservation date cannot be before today's date!");
    input.value = today;
  }
  
  input.setAttribute('data-dirty', 'true');
}
</script>  

