

-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: hotel
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `client_name` varchar(50) NOT NULL,
  `client_phone` varchar(20) NOT NULL,
  `client_email` varchar(50) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (9,'Fatima Zohra','0624367876','fatima.zohra@gmail.com'),(10,'Mohammed Sadiq','0637272727','mohammed.sadiq@gmail.com'),(11,'Houda Zraidi','0666333311','houda.zraidi@gmail.com'),(13,'Sofia Benmoussa','0648484848','sofia.benmoussa@gmail.com'),(14,'Amine Taoufik','0666666666','amine.taoufik@yahoo.fr'),(20,'ANDY OKUBA','0759562522','andyokuba254@gmail.com'),(21,'ANDY OKUBA','0759562522','andyokuba254@gmail.com'),(22,'ashlee manny','0759562522','mamama@gmail.com'),(23,'ANDY OKUBA','0759562522','andyokuba254@gmail.com'),(24,'Milicent buttoniela','0759562522','bbbbbsbsxsxsxs@gmail.com');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image_gallery`
--

DROP TABLE IF EXISTS `image_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image_gallery` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `image_name` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_gallery`
--

LOCK TABLES `image_gallery` WRITE;
/*!40000 ALTER TABLE `image_gallery` DISABLE KEYS */;
INSERT INTO `image_gallery` VALUES (1,'moroccan tajine','82195_6222697471_526dea5458_b.jpg'),(2,'Italian Pasta','img_1.jpg'),(3,'Cook','8040_photo0jpg.jpg'),(4,'restaurant','36511_shiro-fit-fit.jpg'),(5,'Burger','87186_b4e8494efd1ed7c46ea839de3d47d640.jpg');
/*!40000 ALTER TABLE `image_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_order`
--

DROP TABLE IF EXISTS `in_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `in_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `menu_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_menu` (`menu_id`),
  KEY `fk_order` (`order_id`),
  CONSTRAINT `fk_menu` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`menu_id`),
  CONSTRAINT `fk_order` FOREIGN KEY (`order_id`) REFERENCES `placed_orders` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_order`
--

LOCK TABLES `in_order` WRITE;
/*!40000 ALTER TABLE `in_order` DISABLE KEYS */;
INSERT INTO `in_order` VALUES (3,7,13,1),(4,7,11,1),(5,8,1,1),(6,8,2,1),(7,9,11,1),(8,103,1,1),(9,104,15,1),(10,105,1,1);
/*!40000 ALTER TABLE `in_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_categories`
--

DROP TABLE IF EXISTS `menu_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(15) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_categories`
--

LOCK TABLES `menu_categories` WRITE;
/*!40000 ALTER TABLE `menu_categories` DISABLE KEYS */;
INSERT INTO `menu_categories` VALUES (1,'APPETIZER'),(2,'VEGETARIAN '),(3,'SPAGHETTI'),(4,'KITFO'),(5,'SPECIALS'),(6,'ENTREE');
/*!40000 ALTER TABLE `menu_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(20) NOT NULL,
  `menu_description` varchar(255) NOT NULL,
  `menu_price` decimal(4,2) NOT NULL,
  `menu_image` varchar(255) NOT NULL,
  `category_id` int NOT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `FK_menu_category_id` (`category_id`),
  CONSTRAINT `FK_menu_category_id` FOREIGN KEY (`category_id`) REFERENCES `menu_categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'TUNA SALAD','Chopped Tuna with fresh tomatoes, hot peppers, onions and topped with house dressing',8.99,'35647_Tuna-Salad-Recipe.jpg',1),(2,'CHICKEN SALAD','chicken with fresh tomatoes, hot peppers, and onions and topped with house dressing',8.99,'6985_ezgif-5-ae2a28a343.jpg',1),(3,'SPECIAL VEGGIE COMBO','Spicy lentils, yellow peas, collard greens, Cabbage, Shiro, and house salad',14.99,'87186_b4e8494efd1ed7c46ea839de3d47d640.jpg',2),(4,'SHIRO WOT','Seasoned chickpea flour cooked in a mild sauce with house salad',11.00,'25021_Shiro-Wat.jpg',2),(5,'DULLET','lamb tripe and lean beef seasoned with herbed Ethio- pian butter, served raw or cooked',16.99,'38779_dullet-lamb-liver-lambKKKKKKKKKKKKKKKKKKOO.jpg',6),(6,'GORED GORED','Chunks of raw fresh beef immersed in a mixture of\r\nspecially seasoned herbed butter, onions, and hot peppers',15.99,'98131_goredgored.jpg',6),(7,'GOMEN BESIGA','Beef stew with collard greens, house spices, and pepper',16.99,'91823_HHJJUJUJUJUJ.jpg',6),(8,'QUANTA FIRFER','Dried beef sauteed with onion, tomatoes, jalapeno, spice, and butter mixed with injera',15.99,'48648_Quanta-Firfir-1-1-1-1.jpg',6),(9,'SUPER VEGGIE','(6 items) Spicy lentils, yellow peas, collard greens, Cabbage, Shiro',32.99,'32794_img_6598.jpg',2),(10,'MISSIR WOT','Red lentils spiced with berbere (red pepper) sauce with house salad',10.99,'70594_1473350482641.jpeg',2),(11,'SHIRO FITFIT','A unique salad of chickpeas flour diced tomatoes tossed with onions, peppers, minced injera fresh lime juice, and olive oil',7.99,'36511_shiro-fit-fit.jpg',1),(12,'TELBA FITFIT','Ground flaxseed mixed with red onion, peppers, and lemon juice, served dipped in injera',7.99,'57623_ethiopian-telba-enjera-firfir.jpg',1),(13,'FISH GOULASH','Cubed fish cooked with onion, tomatoes, jalapeno, and our special sauce',16.99,'82195_6222697471_526dea5458_b.jpg',6),(14,'BOZENA SHIRO','A rich and savory stew of shiro simmered with beef, nitir kibe, and a combination of Ethiopian spices',12.99,'89909_HJHJHJHJHJH.jpg',6),(15,'PAN FRIED FISH','Fried fish served with salad and rice',16.99,'48379_b5c8937fc5319574ef9fd7d5b35b75f2.jpg',6),(16,'MIXED SALAD','Lettuce Tomato onion Jalapeno, potato, and beetroot with house dressing',4.99,'97417_AR-14452-GreenSalad-0025-4x3-527a1d42f2c042c9bcaf1a68223d34e5.jpg',1),(18,'AWAZE TIBS','Prime Rib sautéed with seasoned butter, Berbere, garlic, onions, tomatoes and jalapeno cooked in a pan',16.99,'98399_LLLLL.jpg',1),(19,'Tomato sauce','Tomato sauce can refer to many different sauces made primarily from tomatoes, usually to be served as part of a dish, rather than as a condiment.',11.99,'52984_TTTT.jpg',3),(20,'Meat sauce','Season ground beef with salt and pepper. In a large skillet, add the beef and chopped onion and brown.',11.99,'43303_RVRVR.jpeg',3),(21,'KITFO SPECIAL','Freshly ground extra lean beef seasoned with spiced butter and hot chili powder. Served with seasoned cottage cheese and collard greens mixed together',16.99,'95909_JFJFJFJFJFJFF.jpg',4),(22,'KITFO MIXED','Freshly minced, very lean beef mixed with gomen and ayb seasoned With spiced butter and mitmita served with injera or kocho',16.99,'50640_kitfo-610x407.jpg',4),(23,'REGULAR PLATTER','(Vegi Combo) with Chicken or AwazeTibs, ( Serves Two )',32.99,'8040_photo0jpg.jpg',5);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `placed_orders`
--

DROP TABLE IF EXISTS `placed_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `placed_orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_time` datetime NOT NULL,
  `client_id` int NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `delivered` tinyint(1) NOT NULL DEFAULT '0',
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `cancellation_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_client` (`client_id`),
  CONSTRAINT `fk_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `placed_orders`
--

LOCK TABLES `placed_orders` WRITE;
/*!40000 ALTER TABLE `placed_orders` DISABLE KEYS */;
INSERT INTO `placed_orders` VALUES (100,'2022-02-25 14:30:00',15,'123 Main Street, Anytown USA',1,0,''),(101,'2022-02-25 15:45:00',20,'25 Park Road, London, UK',0,1,'Sorry! I changed my mind!'),(102,'2022-02-25 18:20:00',17,'Rua da Liberdade 101, Lisbon, Portugal',1,0,NULL),(103,'2023-03-16 11:41:00',20,'+254759562522, +254759562522',0,1,'Not serioud'),(104,'2023-03-16 11:42:00',21,'+254759562522, +254759562522',1,0,NULL),(105,'2023-03-16 12:57:00',23,'+254759562522, +254759562522',0,0,NULL);
/*!40000 ALTER TABLE `placed_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `client_id` int NOT NULL,
  `selected_time` datetime NOT NULL,
  `nbr_guests` int NOT NULL,
  `table_id` int NOT NULL,
  `liberated` tinyint(1) NOT NULL DEFAULT '0',
  `canceled` tinyint(1) NOT NULL DEFAULT '0',
  `cancellation_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reservation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (1,'2020-07-18 09:07:00',13,'2020-07-30 09:07:00',0,1,0,0,NULL),(2,'2020-07-18 09:11:00',14,'2020-07-29 13:00:00',4,1,0,0,NULL),(3,'2023-03-16 12:56:00',22,'2023-03-17 12:56:00',3,1,0,0,NULL),(4,'2023-03-16 13:01:00',24,'2023-03-31 13:01:00',4,1,0,0,NULL);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tables`
--

DROP TABLE IF EXISTS `tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tables` (
  `table_id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tables`
--

LOCK TABLES `tables` WRITE;
/*!40000 ALTER TABLE `tables` DISABLE KEYS */;
INSERT INTO `tables` VALUES (1);
/*!40000 ALTER TABLE `tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'kalkidan','test_test@gmail.com','Idriss Jairi','f7c3bc1d808e04732adf679965ccc34ca7ae3441');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_settings`
--

DROP TABLE IF EXISTS `website_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `website_settings` (
  `option_id` int NOT NULL AUTO_INCREMENT,
  `option_name` varchar(255) NOT NULL,
  `option_value` varchar(255) NOT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;


CREATE TABLE table_reservation (
  id INT NOT NULL AUTO_INCREMENT,
  date DATE NOT NULL,
  time TIME NOT NULL,
  num_people INT NOT NULL,
  client_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  PRIMARY KEY (id)
);

/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_settings`
--

LOCK TABLES `website_settings` WRITE;
/*!40000 ALTER TABLE `website_settings` DISABLE KEYS */;
INSERT INTO `website_settings` VALUES (1,'restaurant_name','Nazret Ethiopia Restaurant'),(2,'restaurant_email','nazretrestaurant@gmail.com'),(3,'admin_email','kalkidan@gmail.com'),(4,'restaurant_phonenumber','7033479911'),(5,'restaurant_address','Ethiopian cuisine in San Falls Church');
/*!40000 ALTER TABLE `website_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-17 20:21:32
