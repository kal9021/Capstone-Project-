<?php 
	session_start();
	$pageTitle = 'Admin Login';

	if(isset($_SESSION['username_restaurant_qRewacvAqzA']) && isset($_SESSION['password_restaurant_qRewacvAqzA']))
	{
		header('Location: dashboard.php');
	}
?>

<!-- PHP INCLUDES -->

<?php include 'connect.php'; ?>
<?php include 'Includes/functions/functions.php'; ?>
<?php include 'Includes/templates/header.php'; ?>

	<!-- LOGIN FORM -->

	<div class="login">
			<form class="login-container validate-form" name="login-form" action="resetPassword.php" method="POST" onsubmit="return validateLoginForm()">
					<span class="login100-form-title p-b-32">
							Reset password
						</span>
						
						<?php

							//Check if user click on the submit button

								if(isset($_POST['admin_login']))
								{
										$username = test_input($_POST['username']);
										

										//Check if User Exist In database

										$stmt = $con->prepare("Select email from users where email = ?;");
										$stmt->execute(array($username));
										$row = $stmt->fetch();
										$count = $stmt->rowCount();

										// Check if count > 0 which mean that the database contain a record about this username

										if($count > 0)
										{

											$email = $row['email'];
											header("Location: Includes/php-files-ajax/contact.php?email=" . urlencode($email));

										}
										else
										{
											?>
										<div class="alert alert-danger">
							<button data-dismiss="alert" class="close close-sm" type="button">
											<span aria-hidden="true">×</span>
									</button>
							<div class="messages">
								<div>User does not exist!</div>
							</div>
						</div>
										<?php 
									}
					}
				?>

				<!-- USERNAME INPUT -->

					<div class="form-input">
							<span class="txt1">Enter email address</span>
								<input type="text" name="username" class = "form-control username" oninput="document.getElementById('username_required').style.display = 'none'" id="user" autocomplete="off">
							<div class="invalid-feedback" id="username_required">Email is required!</div>
					</div>


			
					<p>
							<button type="submit" name="admin_login" >Reset</button>
					</p>

					<!-- FORGOT PASSWORD PART -->

					

				</form>
		</div>

<?php include 'Includes/templates/footer.php'; ?>
