<?php include 'connect.php'; ?>
<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    include '../functions/functions.php';
    
	
        require "vendor/autoload.php";

        $email = $_GET['email'];
        $stmt = $con->prepare("Select email from users where email = ?;");
        $stmt->execute(array($email));
        $row = $stmt->fetch();
        $count = $stmt->rowCount();


       
        $contact_subject = "Reset Password";
        $contact_message = "Please click on the link below to reset the password: https://helios.vse.gmu.edu/~kmeheret/IT493/restaurant/admin/Includes/php-files-ajax/recoverPass.php?email=" . urlencode($email);

     
        $mail = new PHPMailer(true);
        $confirmation = false;
        try {

            $mail->isSMTP();
            $mail->SMTPAuth = true;
            $mail->Host = "smtp.gmail.com";
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->Username = "nazretrestaurant2023@gmail.com";
            $mail->Password = "xlfwtyildlpprgwm";
            $mail->setFrom("nazretrestaurant2023@gmail.com");
            $mail->addAddress("$email");
            $mail->Subject = $contact_subject;
            $mail->Body = $contact_message;
        
            // Send email
           $confirmation = $mail->send();
        
            // Email sent successfully
            echo "Email sent successfully!";
        } catch (Exception $e) {
            // Email failed to send
            echo "Error sending email: " . $mail->ErrorInfo;
        }





        //$mail = mail("your email", $contact_subject, $contact_message);

        if($confirmation)
        {
            ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    The message has been sent successfully
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php
        }
        else
        {
            ?>

                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    A problem occurred while trying to send the Message, Please try again!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

            <?php
        }

	

?>