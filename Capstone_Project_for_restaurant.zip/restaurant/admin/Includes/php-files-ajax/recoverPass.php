<html>
    <head>
        <title>Recover Password</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <body>
<?php include 'connect.php'; ?>
<?php 
error_reporting(0);
$email = $_GET['email'];
$stmt = $con->prepare("Select * from users where email = ?;");
$stmt->execute(array($email));
$row = $stmt->fetch();

if($_POST['password']){
    $updated_password = sha1($_POST['password']);
    $stmt = $con->prepare("UPDATE users SET password = ? WHERE email = ?;");
    $stmt->execute(array($updated_password, $email));
    echo "<p style='color:green; text-align:center; font-size:28px; margin-top: 200px !important;'> Password changed successfully!</p>";
   
}
else{
    echo "";
}



?>
<div class="container mt-5" style="margin-top: 50px !important;">
    
    <div class="col-md-4"></div>
    <div class="col-md-4">
    <form action="" onsubmit="return validateForm()" method="post">
  <div class="form-group">
    <label for="email">Enter new password:</label>
    <input type="password" class="form-control" placeholder="Enter password" id="email" required>
  </div>
  <div class="form-group">
    <label for="pwd">Confirm new password:</label>
    <input type="password" class="form-control" placeholder="Enter password" id="pwd" required name="password">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

    </div>
    <div class="col-md-4"></div>
</div>


<script>
  function validateForm() {
    var newPassword = document.getElementById("email").value;
    var confirmPassword = document.getElementById("pwd").value;
    
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match");
      return false;
    }
  }
</script>
</body>
</html>