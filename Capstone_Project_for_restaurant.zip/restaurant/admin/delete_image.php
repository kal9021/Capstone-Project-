<?php

// Check if the image name parameter is provided
if (!isset($_POST['image_name'])) {
    echo 'Missing image name parameter';
    exit;
}

$image_name = $_POST['image_name'];

// Connect to the database
$con = new PDO("mysql:host=localhost;dbname=hotel", "root", "SCT212-0087/2017");

// Delete the image from the database
$stmt = $con->prepare("DELETE FROM image_gallery WHERE image_name = ?");
$stmt->execute(array($image_name));

// Check if the image was deleted successfully
if ($stmt->rowCount() > 0) {
    // Delete the image file from the server
    $image_file = "uploads/" . $image_name;
    echo $image_name;
    if (file_exists($image_file)) {
        unlink($image_file);
    }

    // Return a success response
    echo 'success';
} else {
    // Return an error response
    echo 'Failed to delete image';
}
