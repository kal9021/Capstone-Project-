<?php
    include '../connect.php';
    include '../Includes/functions/functions.php';

    if(isset($_POST['do_']) && $_POST['do_'] == "Cancel_Order")
    {
        $order_id = $_POST['order_id'];

        $stmt = $con->prepare("DELETE FROM table_reservation WHERE id = ?");
        $stmt->execute(array($order_id));

        echo "Reservation cancelled successfully.";
    }
?>
