<?php 
 include 'connect.php';

// Prepare and execute a SQL query to insert the data into the table
$stmt = $con->prepare("INSERT INTO users (username, full_name, email, password) VALUES (?, ?, ?, ?)");
$stmt->bindParam(1, $username);
$stmt->bindParam(2, $full_name);
$stmt->bindParam(3, $email);
$stmt->bindParam(4, $password);
$username = $_POST["uname"];
$full_name = $_POST["fname"];
$email = $_POST["email"];
$password = sha1($_POST["password"]);
$stmt->execute();


// Close the database connection and redirect the user to a success page
$stmt = null;
$con = null;


echo "<p class='text-success h4'>User added successfully!</p>";

header("Location: users.php");


exit();




?>