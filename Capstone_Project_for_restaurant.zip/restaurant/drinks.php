<?php

    include "connect.php";
    include 'Includes/functions/functions.php';
    include "Includes/templates/header.php";
    include "Includes/templates/navbar.php"; ?>


 <div class="row">
 <div class="col-sm-1"></div>
  <div class="col-sm-5">
  <h3 class="text-center mt-3 text-warning">Hot Beverages</h3>
    <table class="table table-hover">
    <thead>
      <tr>
        <th>Name </th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>COFFEE</td>
        <td>8.00 $</td>
        
      </tr>
      <tr>
        <td>ESPRESSO</td>
        <td>10.00 $</td>
       
      </tr>
      <tr>
        <td>MACCHIATO</td>
        <td>15.00 $</td>
        
      </tr>
      <tr>
        <td>HOT TEA</td>
        <td>12.00 $</td>
      </tr>
      <tr>
        <td>GREEN TEA</td>
        <td>11.00 $</td>
      </tr>
      <tr>
        <td>CAFE LATTE</td>
        <td>11.00 $</td>
      </tr>
    </tbody>
  </table>

</div>
  <div class="col-sm-5">
  <h3 class="text-center mt-3  text-primary">Cold Beverages</h3>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Name </th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>SODA</td>
        <td>8.00 $</td>
        
      </tr>
      <tr>
        <td>CLUB SODA</td>
        <td>10.00 $</td>
       
      </tr>
      <tr>
        <td>BOTTLED WATER</td>
        <td>15.00 $</td>
        
      </tr>
      <tr>
        <td>HEINEKEN</td>
        <td>12.00 $</td>
      </tr>
      <tr>
        <td>BECKS'S</td>
        <td>11.00 $</td>
      </tr>
      <tr>
        <td>COORS EDGE</td>
        <td>11.00 $</td>
      </tr>
      <tr>
        <td>JUICE</td>
        <td>11.00 $</td>
      </tr>
    </tbody>
  </table>
  </div>
  <div class="col-sm-1"></div>
</div>